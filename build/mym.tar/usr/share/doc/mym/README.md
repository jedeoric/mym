mym

Issue : it seems that when when we load with fread the music the code is overlap with the data. 

For example, if we do a "printf("%s",argv[1])"  for example argv1 is corrupted after the fread. I did not have a look with this issue